// package com.sensei.backend.controller;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.web.bind.annotation.*;

// import com.sensei.backend.entity.Coupon;
// import com.sensei.backend.service.CouponService;

// @RestController
// @RequestMapping("/api/coupon")
// public class CouponController {

//     @Autowired
//     private CouponService couponService;

//     @PostMapping("/create")
//     public Coupon createCoupon(@RequestBody Coupon coupon) {
//         return couponService.createCoupon(coupon);
//     }

//     @PostMapping("/apply")
//     public Object applyCoupon(@RequestParam String userId, @RequestParam String couponCode) {
//         return couponService.applyCoupon(userId, couponCode);
//     }
// }
