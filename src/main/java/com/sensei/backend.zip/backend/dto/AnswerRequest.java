package com.sensei.backend.dto;

public class AnswerRequest {
    // TODO: fields will be added later if needed.
    // For now this is just a placeholder so the project can compile.
}
