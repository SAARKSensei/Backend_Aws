package com.sensei.backend.enums;

public enum PlanStatus {
    ACTIVE,
    EXPIRED,
    NONE
}
