package com.sensei.backend.enums;

public enum ProcessTrackingStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}
