// package com.sensei.backend.service;

// import com.sensei.backend.entity.ContactUs;
// import com.sensei.backend.error.UserNotFoundException;

// import java.util.List;

// public interface ContactUsService {

//     public ContactUs saveUser(ContactUs user);

//     public List<ContactUs> fetchUserList();

//     public ContactUs fetchUserById(Long userId) throws UserNotFoundException;

//     public void deleteUserById(Long userId);

//     public ContactUs updateUser(Long userId, ContactUs user);

//     public ContactUs fetchUserByName(String userName);
// }