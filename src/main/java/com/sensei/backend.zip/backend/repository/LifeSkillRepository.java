// package com.sensei.backend.repository;

// import java.util.Optional;
// import com.sensei.backend.entity.LifeSkill;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.stereotype.Repository;
// import java.util.UUID;

// @Repository
// public interface LifeSkillRepository extends JpaRepository<LifeSkill, String> {
// 	Optional<LifeSkill> findByLifeskillNameIgnoreCase(String lifeskillName);
// }
