// package com.sensei.backend.repository;

// import com.sensei.backend.entity.DigitalActivityResultCalculator;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.stereotype.Repository;

// import java.util.Optional;

// @Repository
// public interface DigitalActivityResultCalculatorRepository extends JpaRepository<DigitalActivityResultCalculator, String> {
//     Optional<DigitalActivityResultCalculator> findByChildIdAndDigitalActivityId(String childId, String digitalActivityId);
// }
