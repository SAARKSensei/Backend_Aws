// package com.sensei.backend.repository;

// import com.sensei.backend.entity.QuizResult;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.stereotype.Repository;
// import java.util.List;

// @Repository
// public interface QuizResultRepository extends JpaRepository<QuizResult, String> {
//     List<QuizResult> findByChildId(String childId);
    
//     void deleteByChildId(String childId);

// }
